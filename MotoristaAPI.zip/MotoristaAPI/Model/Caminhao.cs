﻿using System.ComponentModel.DataAnnotations;

namespace MotoristaAPI.Model
{
    public class Caminhao
    {
        [Key]
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Placa { get; set; }
        public string Cor { get; set; }
        public int CaminhoneiroId { get; set; }
        public Caminhoneiro Caminhoneiro { get; set; }

        public Caminhao(string marca, string placa, string cor, int caminhoneiroId)
        {
            Marca = marca;
            Placa = placa;
            Cor = cor;
            CaminhoneiroId = caminhoneiroId;

        }
    }
}
