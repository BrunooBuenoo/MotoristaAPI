﻿using System.ComponentModel.DataAnnotations;

namespace MotoristaAPI.Model
{
    public class Caminhoneiro
    {

        [Key]
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Cpf { get; set; }

        public Caminhoneiro(string nome, string cpf)
        {
            Nome = nome;
            Cpf = cpf;
        }
    }
}
