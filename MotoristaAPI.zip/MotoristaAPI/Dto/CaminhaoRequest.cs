﻿using Microsoft.Extensions.Hosting;
using MotoristaAPI.Model;
using System.ComponentModel.DataAnnotations;

namespace MotoristaAPI.Dto
{
    public class CaminhaoRequest
    {
        [MinLength(5)]
        public string Marca { get; set; }
        public string Placa { get; set; }
        public string Cor { get; set; }

        [Required]
        public int CaminhoneiroId { get; set; }

        public Caminhao toModel()
            => new Caminhao(Marca, Placa, Cor, CaminhoneiroId);
    }
}
