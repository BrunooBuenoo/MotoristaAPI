﻿using Microsoft.Extensions.Hosting;
using MotoristaAPI.Model;

namespace MotoristaAPI.Dto
{
    public class CaminhaoResponse
    {
        public string Marca { get; set; }
        public string Placa { get; set; }
        public string Cor { get; set; }
        public Caminhoneiro Caminhoneiro { get; set; }

        public CaminhaoResponse(Caminhao caminhao)
        {
            Marca = caminhao.Marca;
            Placa = caminhao.Placa;
            Cor = caminhao.Cor;
            Caminhoneiro = caminhao.Caminhoneiro;
        }
    }
}
