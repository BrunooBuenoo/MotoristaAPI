﻿using MotoristaAPI.Model;
using System.ComponentModel.DataAnnotations;

namespace MotoristaAPI.Dto
{
    public class CaminhoneiroRequest
    {
        [MinLength(10)]
        public string Nome { get; set; }
        public string Cpf { get; set; }

        public Caminhoneiro toModel()
            => new Caminhoneiro(Nome, Cpf);
    }
}
