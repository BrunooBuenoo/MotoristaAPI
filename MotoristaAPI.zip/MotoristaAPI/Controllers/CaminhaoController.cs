﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MotoristaAPI.Context;
using MotoristaAPI.Dto;
using MotoristaAPI.Model;
using System.Linq;

namespace MotoristaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CaminhaoController : ControllerBase
    {
        private readonly DataContext _dataContext;

        public CaminhaoController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<CaminhaoController>
        [HttpGet]
        public ActionResult<List<Caminhao>> Get()
        {
            var caminhoes = _dataContext.Caminhao.ToList<Caminhao>();
            return caminhoes;
        }

        // GET api/<CaminhaoController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<CaminhaoController>
        [HttpPost]
        public ActionResult<Caminhao> Post([FromBody] CaminhaoRequest caminhaoRequest)
        {
            if (ModelState.IsValid)
            {
                var caminhao = caminhaoRequest.toModel();
                _dataContext.Caminhao.Add(caminhao);
                _dataContext.SaveChanges();
                return caminhao;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<CaminhaoController>/5
        [HttpPut]
        public ActionResult<Caminhao> Put([FromBody] Caminhao caminhao)
        {
            var caminhaoENulo = _dataContext.Caminhao.FirstOrDefault(caminhao) == null;
            if (caminhaoENulo)
                ModelState.AddModelError("CaminhaoId", "Id do caminhao não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Caminhao.Update(caminhao);
                _dataContext.SaveChanges();
                return caminhao;
            }
            return BadRequest(ModelState);

        }

        // DELETE api/<CaminhaoController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var caminhao = _dataContext.Caminhao.Find(id);
            if (caminhao == null)
                ModelState.AddModelError("CaminhaoId", "Id do caminhao não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Caminhao.Remove(caminhao);
                _dataContext.SaveChanges();
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}
