﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using MotoristaAPI.Context;
using MotoristaAPI.Dto;
using MotoristaAPI.Model;
using System.Linq;

namespace MotoristaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CaminhoneiroController : ControllerBase
    {
        private readonly DataContext _dataContext;

        public CaminhoneiroController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<CaminhoneiroController>
        [HttpGet]
        public ActionResult<List<Caminhoneiro>> Get()
        {
            var caminhoneiros = _dataContext.Caminhoneiro.ToList<Caminhoneiro>();
            return caminhoneiros;
        }

        // GET api/<CaminhoneiroController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<CaminhoneiroController>
        [HttpPost]
        public ActionResult<Caminhoneiro> Post([FromBody] CaminhoneiroRequest postRequest)
        {
            if (ModelState.IsValid)
            {
                var caminhoneiro = postRequest.toModel();
                _dataContext.Caminhoneiro.Add(caminhoneiro);
                _dataContext.SaveChanges();
                return caminhoneiro;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<CaminhoneiroController>/5
        [HttpPut]
        public ActionResult<Caminhoneiro> Put([FromBody] Caminhoneiro caminhoneiro)
        {
            var caminhoneiroENulo = _dataContext.Caminhoneiro.FirstOrDefault(caminhoneiro) == null;
            if (caminhoneiroENulo)
                ModelState.AddModelError("CaminhoneiroId", "Id do caminhoneiro não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Caminhoneiro.Update(caminhoneiro);
                _dataContext.SaveChanges();
                return caminhoneiro;
            }
            return BadRequest(ModelState);

        }

        // DELETE api/<CaminhoneiroController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var caminhoneiro = _dataContext.Caminhoneiro.Find(id);
            if (caminhoneiro == null)
                ModelState.AddModelError("CaminhoneiroId", "Id do caminhoneiro não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Caminhoneiro.Remove(caminhoneiro);
                _dataContext.SaveChanges();
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}
