﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using MotoristaAPI.Model;

namespace MotoristaAPI.Context
{
    public class DataContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=MotoristaBD;ConnectRetryCount=0");
        }

        public DbSet<Caminhoneiro> Caminhoneiro { get; set; }
        public DbSet<Caminhao> Caminhao { get; set; }
    }
}
